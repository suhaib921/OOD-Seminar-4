package se.kth.iv1350.seminar4.controller;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.seminar4.controller.Controller;
import se.kth.iv1350.seminar4.dto.ItemDTO;
import se.kth.iv1350.seminar4.integration.DatabaseServerNotRunningException;
import se.kth.iv1350.seminar4.integration.NoSuchItemFoundException;
import se.kth.iv1350.seminar4.util.Logger;

import java.sql.SQLException;
import java.util.ArrayList;
import se.kth.iv1350.seminar4.dto.ItemDTO;
import se.kth.iv1350.seminar4.dto.SaleDTO;
import se.kth.iv1350.seminar4.integration.AccountingSystem;
import se.kth.iv1350.seminar4.integration.DatabaseServerNotRunningException;
import se.kth.iv1350.seminar4.integration.DiscountRegister;
import se.kth.iv1350.seminar4.integration.InventorySystem;
import se.kth.iv1350.seminar4.integration.NoSuchItemFoundException;
import se.kth.iv1350.seminar4.integration.Printer;
import se.kth.iv1350.seminar4.modell.Payment;
import se.kth.iv1350.seminar4.modell.Receipt;
import se.kth.iv1350.seminar4.modell.Sale;
import se.kth.iv1350.seminar4.modell.SaleLog;
import se.kth.iv1350.seminar4.modell.SaleObserver;
import se.kth.iv1350.seminar4.util.Logger;

class ControllerTest {
    private Controller controller;
    private Logger logger;

    @BeforeEach
    void setUp() {
    
        controller = new Controller(logger);
        controller.startSale(); 
    }

    @Test
    void testScanItemSuccessfully() {
        int validItemID = 1; 
        int quantity = 2;

        try {
            ItemDTO item = controller.scanItem(validItemID, quantity);
            assertNotNull(item, "Item should not be null when scanned successfully");
            assertEquals(validItemID, item.getItemID(), "The item ID should match the input item ID");
        } catch (Exception e) {
            fail("Exception should not be thrown for a valid item ID: " + e.getMessage());
        }
    }
    
    
    /**
     * -1 is an invalidItemID
     */

    @Test
    void testScanItemThrowsNoSuchItemFoundException() {
        int invalidItemID = -1;
        int quantity = 1;

        Exception exception = assertThrows(NoSuchItemFoundException.class, () -> {
            controller.scanItem(invalidItemID, quantity);
        });

        String expectedMessage = "Invalid item identifier: " + invalidItemID;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

   
}
