package se.kth.iv1350.seminar4.controller;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.seminar4.dto.ItemDTO;

import se.kth.iv1350.seminar4.modell.Sale;
import se.kth.iv1350.seminar4.util.ErrorLogger;
import se.kth.iv1350.seminar4.integration.*;

public class ControllerTest {
    private Controller controller;
    

    @BeforeEach
    public void setUp() {
        controller = new Controller(new ErrorLogger());
        controller.startSale();
        
    }

    @AfterEach
    public void tearDown() {
        controller = null;
    }
    
    
    /**
     * Test if the testNoSuchItemFoundException() is thrown when the itemID is not valid
     */
   
   @Test
    public void invalidItemid() {
        int itemID = 999;
        int quantity = 2;

        
        Exception exception = assertThrows(NoSuchItemFoundException.class, () -> {
            controller.scanItem(itemID, quantity);
        });

        
        String expectedMessage = "Invalid item identifier: " + itemID;
        String actualMessage = exception.getMessage();
        assertEquals(expectedMessage, actualMessage);
    }
   
   /**
    * Test if the DatabaseServerNotRunningException() is thrown when the itemID is equal to 12. That is how we simulate that such an exception is thrown.
    */
   
   @Test
   public void serverNotRunning() {
       int itemID = 12;
       int quantity = 2;

       
       Exception exception = assertThrows(DatabaseServerNotRunningException.class, () -> {
           controller.scanItem(itemID, quantity);
       });

       
       String expectedMessage = "ERROR: Connection to the inventory server has failed";
       String actualMessage = exception.getMessage();
       assertEquals(expectedMessage, actualMessage);
   }

    
    
   

  

   
}


